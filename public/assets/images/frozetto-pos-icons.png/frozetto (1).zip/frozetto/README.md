# Frozetto - Management System

React (Vite + Tailwind) + Node/Express + MongoDB.

## Setup
```bash
# Backend
cd backend
npm install
cp .env.example .env      # phir .env mein MONGO_URI, JWT_SECRET, SHOP_NAME, SHOP_ADDRESS, SHOP_PHONE SHOP_GSTIN, SHOP_STATE, SHOP_EMAIL bhi bharo
node seedAdmin.js         # admin@shop.com / admin123 (login ke baad password badal do)
node seedProducts.js      # optional: sample products
npm run dev               # http://localhost:5000

# Frontend (naye terminal mein)
cd frontend
npm install
cp .env.example .env      # VITE_API_URL=http://localhost:5000/api
npm run dev               # http://localhost:5173
```

## Logo
`backend/assets/logos/logo.png` naam se PNG rakh do (details usi folder ke README.txt mein). Logo app ke header/login,
PDF bill aur bill screen par apne aap aa jayega. Logo na ho to emoji dikhega, kuch tootega nahi.

## Signature
`backend/assets/logos/signature.png` (ya `signature.jpg`) rakh do - PDF aur preview dono mein "For: Frozetto" ke neeche, "Authorized Signatory" ke upar aayega.
Safed/transparent background par saaf signature best rahega. Na ho to wahan khaali jagah rehti hai (haath se sign kar sakte ho).

## Bill kaise milta hai (PDF + WhatsApp)
Bill banne ke baad receipt screen par sirf 2 option: **📄 Download PDF** (GST Tax Invoice, logo ke saath) aur **💬 Share WhatsApp**.
Customer ka phone number bhara ho to WhatsApp seedha usi number par khulta hai.

## Is version mein kya naya hai
- **Customer info compulsory:** har bill par customer ka **naam, phone (10 digit) aur address** bharna padta hai (billing screen par sabse upar). Bina iske bill nahi banta - backend bhi check karta hai.
- **PDF = Preview:** bill ke baad screen par bilkul PDF jaisa Tax Invoice dikhta hai (logo, shop address, customer address, SGST@2.5% / CGST@2.5%, amount in words, signature). Phone par poora page screen mein fit hota hai, "Zoom" dabake 100% mein padh sakte ho.
- GST **lagti hai** (product ke GST% ke hisaab se), bill par SGST/CGST + GSTIN
- **Cash return calculator:** Cash select karo -> "Customer ne diye" mein amount (ya 250/300/500 quick button) -> bada sa **"Wapas do ₹270"**. Reports mein cash sale sahi (230) hi jaati hai, 500 nahi. Bill par "Cash given / Change returned" bhi chhapta hai.
- **Payment auto-fill:** Cash/UPI/Card chunte hi bill total apne aap bhar jaata hai (edit kar sakte ho). Split payment (Cash + UPI) mein doosri row baaki amount khud le leti hai.
- **Black strip / kata hua button fix:** floating black bar hata ke sticky checkout bar (Generate Bill button ke saath) - ab kuch dhakta nahi.
- **Naya navigation:** mobile par 4 buttons (Home, New Bill, Bills, More). Products/Reports/Staff/Logout "More" mein.
- **Billing screen:** Menu / Cart tabs, bade touch buttons, category chips, customer details optional (collapsed).
- **Stock track on/off:** Product add/edit mein "Stock track karo" checkbox - made-to-order items ke liye band rakho.
- **Bill number safe:** ek saath do phone se bill banao to bhi duplicate nahi banega. Format: `FRZ-0001`.
- "Credit" payment mode hata diya - udhaar ke liye bas payment kam bharo, baaki "Balance Due" ban jaata hai.

## Purana data
Migration ki zarurat nahi - purane products/bills waise hi chalte hain (purane bills ka number purane prefix ke saath dikhega, naye bills `FRZ-0001` se shuru).

## Deploy
Frontend `vercel.json` ke saath Vercel par, backend kisi Node host par. Backend `.env` mein `CLIENT_URL` = frontend ka URL,
frontend `.env` mein `VITE_API_URL` = backend ka `/api` URL. Logo backend se serve hota hai (`/logos/logo.png`).
